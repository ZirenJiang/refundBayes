# refundBayes Vignette

2025-02-03

In this simple vignette, we introduce the use of our $\texttt{rnhanesdata}$ package with the NHANES dataset. The $\texttt{rnhanesdata}$ package provides users a continent way to run Bayesian functional data analysis using the Stan language which is the state-of-the-art language for Bayesian analysis. Our R package $\texttt{rnhanesdata}$ was developed to have a similar syntax to that in $\texttt{mgcv::gam}$, though it uses Bayesian posterior inference and a few additional arguments that are specific to the Stan implementation. Specifically, in this vignette, we illustrate how to use our $\texttt{rnhanesdata}$ package to:

-   Fit the Bayesian functional regression model with scalar (Binary, Gaussian) outcomes using Stan.

-   Plot the pointwise and the correlation and multiplicity adjusted (CMA) credible intervals for the estimated functional coefficients.

-   Bayesian model diagnostics with the trace plot.

We compare our Bayesian model output with the state-of-the-art frequentist package mgcv in terms of the estimation of the functional coefficient.

# Preperation

## Install the refundBayes package

The $\texttt{rnhanesdata}$ package can be installed through the source file:

``` r
#install.packages("refundBayes_0.2.tar.gz", type = "source", repos=NULL)
```

## Prepare the illustrative NHANES data set

NHANES (National Health and Nutrition Examination Survey) is a nationwide study conducted by the United States Centers for Disease Control and Prevention (CDC) to assess the health and nutritional status of adults and children in the United States. It is conducted in two-year waves with approximately $10{,}000$ participants per wave.

In this illustrative example, we apply our Bayesian functional regression programs to study the association between scalar and functional predictors and mortality in the NHANES. The functional predictor is the minute-level average daily physical activity measured using accelerometers. Accelerometry data was summarized by NHANES at the minute level using the "Monitor Independent Movement Summary" (MIMS) units. The distribution of MIMS at each time point exhibits substantial skewness and a log-transformation was applied at the minute level, which resulted in more symmetric marginal distributions. For every individual, data was averaged over available days of that individual at each minute, resulting in a $1{,}440$-dimensional vector of average log-MIMS values for every study participant. Processing was conducted using a similar pipeline to that described in the $\texttt{rnhanesdata}$ package. Mortality was determined by linking the NHANES data to death certificate records from the National Death Index, maintained by the National Center for Health Statistics (NCHS), through the end of 2019.

In this case study, the outcome is a binary indicator of whether or not the person died before 2019 (that is, the five-year mortality indicator). The predictors are the minute-level physical activity expressed in average log-MIMS, age, gender, race, body mass index (BMI), poverty-to-income ratio (PIR), coronary heart disease (CHD), and education level. The data after preprocessing can be downloaded from

<http://www.ciprianstats.org/sites/default/files/nhanes/nhanes_fda_with_r.rds>

After download the data, we subset the data with subjects whose covariates are fully observed.

``` r
set.seed(12345)
# Load the data, you may to your own path
nhanes_fda_with_r = readRDS("D:/Code/R/18. FDA Survival/18. FDA Survival/nhanes_fda_with_r.rds")

# We only include participants with fully observed covariates
nhanes_lite_use=nhanes_fda_with_r
pred.names=c("age","gender","race","BMI","PIR","CHD","education")
pred.names.cat=c("gender","race","CHD","education")
for(cova in pred.names){
  nhanes_lite_use=nhanes_lite_use[!is.na(nhanes_lite_use[cova]),]
}
nhanes_lite_use=nhanes_lite_use[!is.na(nhanes_lite_use$event),]
nhanes_lite_use=nhanes_lite_use[-which(nhanes_lite_use$CHD=="Refused"),]

# Create the auxiliary matrices for fitting the functional regression 
nhanes_lite_use$lmat = I(matrix(1/1440, ncol=1440, nrow=nrow(nhanes_lite_use))) 
nhanes_lite_use$tmat = I(matrix(1:1440, ncol=1440, nrow=nrow(nhanes_lite_use), byrow=TRUE))

# Outcome variable of five year mortality
nhanes_lite_use$five_year_mort = (nhanes_lite_use$time<60)&(nhanes_lite_use$event==1)
```

# Frequentist approach

## Fit the frequentist model using mgcv

We first fit the scalar-on-function regression model using the frequentist $\texttt{mgcv}$ package.

``` r
library(mgcv)
```

```         
## 载入需要的程辑包：nlme

## This is mgcv 1.9-1. For overview type 'help("mgcv-package")'.
```

``` r
fit_freq_b = gam(five_year_mort ~ age+gender+race+BMI+PIR+CHD+education + s(tmat,  by=lmat*MIMS, bs="cc", k=10), data=nhanes_lite_use, family=binomial())
```

## Frequentist inference on the functional coefficient

The pointwise confidence interval can be directly obtained through the $\texttt{plot.gam}$ function. However, to obtain the correlation and multiplicity adjusted (CMA) confidence interval, we need to manually calculate using the joint distribution of the estimated parameters (describe later).

``` r
# Obtain the pointwise confidence interval for the functional coefficient
plotfot.condi=plot.gam(fit_freq_b,unconditional = FALSE)
```

![](refundBayes_Vignette_Combine_files/figure-gfm/unnamed-chunk-4-1.png)<!-- -->

``` r
summary(fit_freq_b)
```

```         
## 
## Family: binomial 
## Link function: logit 
## 
## Formula:
## five_year_mort ~ age + gender + race + BMI + PIR + CHD + education + 
##     s(tmat, by = lmat * MIMS, bs = "cc", k = 10)
## 
## Parametric coefficients:
##                                  Estimate Std. Error z value Pr(>|z|)    
## (Intercept)                     -3.732099   0.551701  -6.765 1.34e-11 ***
## age                              0.063007   0.004641  13.577  < 2e-16 ***
## genderFemale                    -0.066124   0.108344  -0.610 0.541652    
## raceOther Hispanic               0.104646   0.298531   0.351 0.725935    
## raceNon-Hispanic White           0.626290   0.236013   2.654 0.007963 ** 
## raceNon-Hispanic Black           0.432116   0.245750   1.758 0.078687 .  
## raceNon-Hispanic Asian          -0.256276   0.337382  -0.760 0.447493    
## raceOther Race                   0.738465   0.395814   1.866 0.062085 .  
## BMI                             -0.022817   0.008126  -2.808 0.004990 ** 
## PIR                             -0.163260   0.039069  -4.179 2.93e-05 ***
## CHDYes                           0.568677   0.155830   3.649 0.000263 ***
## CHDDon't know                    1.323754   0.483516   2.738 0.006186 ** 
## educationHigh school equivalent -0.143314   0.143111  -1.001 0.316625    
## educationMore than high school  -0.368270   0.138175  -2.665 0.007694 ** 
## educationDon't know              1.811336   1.277304   1.418 0.156164    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Approximate significance of smooth terms:
##                       edf Ref.df Chi.sq p-value    
## s(tmat):lmat * MIMS 2.908  3.398  108.5  <2e-16 ***
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## R-sq.(adj) =  0.197   Deviance explained = 26.8%
## UBRE = -0.64958  Scale est. = 1         n = 7605
```

# Bayesian approach

## Fit the Bayesian model using refundBayes

We now fit the Bayesian functional regression model using our $\texttt{refundBayes}$ package. The bfrs function from $\texttt{refundBayes}$ package uses a similar argument as the gam function. It automatically generates the Stan code, and Stan data according to the input formula and dataset. ()

``` r
library(refundBayes)
```

```         
## 载入需要的程辑包：Rcpp

## 载入需要的程辑包：rstan

## 载入需要的程辑包：StanHeaders

## 
## rstan version 2.32.5 (Stan version 2.32.2)

## For execution on a local, multicore CPU with excess RAM we recommend calling
## options(mc.cores = parallel::detectCores()).
## To avoid recompilation of unchanged Stan programs, we recommend calling
## rstan_options(auto_write = TRUE)
## For within-chain threading using `reduce_sum()` or `map_rect()` Stan functions,
## change `threads_per_chain` option:
## rstan_options(threads_per_chain = 1)

## Do not specify '-march=native' in 'LOCAL_CPPFLAGS' or a Makevars file

## Warning: replacing previous import 'dplyr::lag' by 'stats::lag' when loading
## 'refundBayes'

## Warning: replacing previous import 'dplyr::filter' by 'stats::filter' when
## loading 'refundBayes'
```

``` r
timeStart = Sys.time()
fit_bfrs = refundBayes::bfrs(five_year_mort ~ age+gender+race+BMI+PIR+CHD+education + s(tmat,  by = lmat*MIMS, bs="cc", k=10), # The bfrs function takes a similar formula syntax to that in the gam function.
      data=nhanes_lite_use, 
      family = binomial(), 
      runStan = TRUE, # Whether automatically run Stan program. If false, bfrs will only provide the Stan code and data after preprocessing.
      n.iter = 15000, # Total number of posterior sampling.
      n.warmup = 5000, # Burn-in value.
      n.knots = 3 # Number of parallel computed chains for posterior sampling. Suggest to have this value larger than 1 in order to check the convergence of the MCMC sampling.
      )
```

```         
## Warning: There were 90 divergent transitions after warmup. See
## https://mc-stan.org/misc/warnings.html#divergent-transitions-after-warmup
## to find out why this is a problem and how to eliminate them.

## Warning: Examine the pairs() plot to diagnose sampling problems
```

``` r
timeEnd = Sys.time()

# Check the running time for Bayesian posterior sampling
difftime(timeEnd, timeStart, units='mins')
```

```         
## Time difference of 24.04791 mins
```

## Bayesian inference

$\texttt{refundBayes}$ package provides a plot function $\texttt{plot.bfrs}$ for the pointwise and CMA credible interval.

``` r
library(ggplot2)
plot.bfrs(fit_bfrs,include = "both")
```

```         
## [[1]]
```

![](refundBayes_Vignette_Combine_files/figure-gfm/unnamed-chunk-6-1.png)<!-- -->

We can also use the $\texttt{summary_scalar.bfrs}$ function for the scalar coefficients.

``` r
summary_scalar.bfrs(fit_bfrs)
```

```         
##                   Scalar Predictor        mean 0.025 quantile 0.975 quantile
## 1                              age  0.06339974     0.05429191    0.072871075
## 2                     genderFemale -0.06704014    -0.28404927    0.147635209
## 3               raceOther Hispanic  0.10704227    -0.48637531    0.690766799
## 4           raceNon-Hispanic White  0.64344779     0.19482219    1.125535658
## 5           raceNon-Hispanic Black  0.44805388    -0.02620712    0.949391515
## 6           raceNon-Hispanic Asian -0.26542926    -0.94152303    0.399010719
## 7                   raceOther Race  0.72476926    -0.07119212    1.501833618
## 8                              BMI -0.02308347    -0.03929492   -0.007268227
## 9                              PIR -0.16456147    -0.24308198   -0.087122168
## 10                          CHDYes  0.56986704     0.26214795    0.875871527
## 11                   CHDDon't know  1.33141402     0.35858958    2.282130456
## 12 educationHigh school equivalent -0.14459417    -0.42754024    0.136299180
## 13  educationMore than high school -0.36791207    -0.63842451   -0.096276536
## 14             educationDon't know  2.20221291    -0.41626029    5.690466185
```

We now compare the estimated functional coefficient between the frequentist and Bayesian methods.

``` r
# Calculate the frequentist CMA confidence interval
testfit=fit_bfrs$spline_basis[[1]]$base_mat %*% fit_freq_b$coefficients[16:24]

Xmat_use = fit_bfrs$spline_basis[[1]]$base_mat
Vb_use = vcov(fit_freq_b)[16:24,16:24]
Vf_use = (Xmat_use %*% Vb_use %*% t(Xmat_use))[(1:100)*14.4,(1:100)*14.4]

Df = sqrt(diag(Vf_use)) #Calculate the correlation matrix 
Cf = cov2cor(Vf_use) #Obtain the critical value for the joint confidence interval 
library(mvtnorm)
qCf_alpha = qmvnorm(0.95, corr = Cf, tail = "both.tails") #Obtain the upper and lower bounds of the joint CI 
uCI_joint = testfit[(1:100)*14.4] + qCf_alpha$quantile * Df 
lCi_joint = testfit[(1:100)*14.4] - qCf_alpha$quantile * Df

func_coeff_samp=fit_bfrs$func_effect[[1]]

func_coeff_sd=apply(func_coeff_samp,2,sd)

func_coeff_extr=1:dim(func_coeff_samp)[1]

func_coeff_est=apply(func_coeff_samp,2,mean)

for(i in 1:dim(func_coeff_samp)[1]){
  func_coeff_extr[i]=max(abs(func_coeff_samp[i,]-func_coeff_est)/func_coeff_sd)
}

cutpoint=quantile(func_coeff_extr,probs = 0.95)


func_coeff_upper_old = func_coeff_est + cutpoint*func_coeff_sd

func_coeff_lower_old = func_coeff_est - cutpoint*func_coeff_sd

func_coeff_upper_pointwise = apply(func_coeff_samp, 2, function(x){
  quantile(x,prob = 0.975)
})

func_coeff_lower_pointwise = apply(func_coeff_samp, 2, function(x){
  quantile(x,prob = 0.025)
})


plotdata2=data.frame(value=c(func_coeff_est,
                            plotfot.condi[[1]]$fit),
                    CI.upper=c(func_coeff_upper_pointwise,
                               plotfot.condi[[1]]$fit+plotfot.condi[[1]]$se),
                    CI.lower=c(func_coeff_lower_pointwise,
                               plotfot.condi[[1]]$fit-plotfot.condi[[1]]$se),
                    CMA.upper = c(func_coeff_upper_old,
                                  uCI_joint),
                    CMA.lower = c(func_coeff_lower_old,
                                  lCi_joint),
                    xmat=c(rep(1: dim(nhanes_lite_use$MIMS)[2]/60,1),
                           rep(plotfot.condi[[1]]$x/60,1)),
                    Method=c(rep("Bayesian",dim(nhanes_lite_use$MIMS)[2]),
                           rep("Frequentist",100)))

library(ggplot2)



ggplot(plotdata2, aes(y = value, x = xmat, color = Method)) +
  geom_line(size = 1) +
  geom_ribbon(aes(ymin = CI.lower, ymax = CI.upper, fill = "Pointwise CI"), 
              alpha = 0.2, color = "black", linetype = "dashed") +
  geom_ribbon(aes(ymin = CMA.lower, ymax = CMA.upper, fill = "CMA CI"), 
              alpha = 0.2, linetype = "dotted", color = "black") +
  ylab("Functional Effect") +
  xlab("Time (hour)") +
  scale_x_continuous(breaks = seq(0, 24, by = 3)) +
  coord_cartesian(xlim = c(0, 24)) +facet_wrap(~ Method)+
  scale_fill_manual(values = c("Pointwise CI" = "darkgrey", "CMA CI" = "lightgrey"), name = "Interval Type") +
  theme_minimal()
```

```         
## Warning: Using `size` aesthetic for lines was deprecated in ggplot2 3.4.0.
## ℹ Please use `linewidth` instead.
## This warning is displayed once every 8 hours.
## Call `lifecycle::last_lifecycle_warnings()` to see where this warning was
## generated.
```

![](refundBayes_Vignette_Combine_files/figure-gfm/unnamed-chunk-8-1.png)<!-- -->

## Bayesian model diagnostic

``` r
traceplot(fit_bfrs$stanfit,pars = c("eta_0","gamma"))
```

![](refundBayes_Vignette_Combine_files/figure-gfm/unnamed-chunk-9-1.png)<!-- -->
