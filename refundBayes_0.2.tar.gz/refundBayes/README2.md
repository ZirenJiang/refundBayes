Illustrative example of BRFS
================

``` r
exampleData <- readRDS("./data/exampleData.rds")

L_num=50
true.beta.func=function(x){
  (-(-0.5+(x-0.5)^2)-0.416)*5
}

true.beta=true.beta.func((1:L_num)/L_num)#+rnorm(1,mean = 1,sd=1)
            
            

fit_freq<- gam(y ~ s(tmat, by=lmat*MIMS, bs="cr", k=10), data=exampleData, family="gaussian")
plotfot=plot(fit_freq)
```

![](README_files/figure-gfm/unnamed-chunk-1-1.png)<!-- -->

``` r
plotfot.upper=plotfot[[1]]$fit+plotfot[[1]]$se
plotfot.lower=plotfot[[1]]$fit-plotfot[[1]]$se

res.CI=c(as.numeric((true.beta<plotfot.upper[(1:50)*2])&(true.beta>plotfot.lower[(1:50)*2])))

plot_inx=c(1,round((1:(L_num-2))*(100/(L_num-1)),0),100)




fit_stan<- bfrs(y ~ s(tmat, by=lmat*MIMS, bs="cr", k=10), data=exampleData, family="gaussian",func_comp="observ")
```

    ## 
    ## SAMPLING FOR MODEL 'anon_model' NOW (CHAIN 1).
    ## Chain 1: 
    ## Chain 1: Gradient evaluation took 0.000133 seconds
    ## Chain 1: 1000 transitions using 10 leapfrog steps per transition would take 1.33 seconds.
    ## Chain 1: Adjust your expectations accordingly!
    ## Chain 1: 
    ## Chain 1: 
    ## Chain 1: Iteration:    1 / 5000 [  0%]  (Warmup)
    ## Chain 1: Iteration:  500 / 5000 [ 10%]  (Warmup)
    ## Chain 1: Iteration: 1000 / 5000 [ 20%]  (Warmup)
    ## Chain 1: Iteration: 1500 / 5000 [ 30%]  (Warmup)
    ## Chain 1: Iteration: 2000 / 5000 [ 40%]  (Warmup)
    ## Chain 1: Iteration: 2001 / 5000 [ 40%]  (Sampling)
    ## Chain 1: Iteration: 2500 / 5000 [ 50%]  (Sampling)
    ## Chain 1: Iteration: 3000 / 5000 [ 60%]  (Sampling)
    ## Chain 1: Iteration: 3500 / 5000 [ 70%]  (Sampling)
    ## Chain 1: Iteration: 4000 / 5000 [ 80%]  (Sampling)
    ## Chain 1: Iteration: 4500 / 5000 [ 90%]  (Sampling)
    ## Chain 1: Iteration: 5000 / 5000 [100%]  (Sampling)
    ## Chain 1: 
    ## Chain 1:  Elapsed Time: 7.742 seconds (Warm-up)
    ## Chain 1:                12.259 seconds (Sampling)
    ## Chain 1:                20.001 seconds (Total)
    ## Chain 1:

    ## Warning: There were 101 divergent transitions after warmup. See
    ## https://mc-stan.org/misc/warnings.html#divergent-transitions-after-warmup
    ## to find out why this is a problem and how to eliminate them.

    ## Warning: Examine the pairs() plot to diagnose sampling problems

    ## Warning: Bulk Effective Samples Size (ESS) is too low, indicating posterior means and medians may be unreliable.
    ## Running the chains for more iterations may help. See
    ## https://mc-stan.org/misc/warnings.html#bulk-ess

    ## Warning: Tail Effective Samples Size (ESS) is too low, indicating posterior variances and tail quantiles may be unreliable.
    ## Running the chains for more iterations may help. See
    ## https://mc-stan.org/misc/warnings.html#tail-ess

``` r
cat(fit_stan$Stancode)
```

    ## data{ 
    ##    int<lower=1> N;
    ##    real Y[N];
    ##    real plocation;
    ##    real pscale;
    ##    int<lower=1> K_s;
    ##    int<lower=1> Kr_1;
    ##    matrix[N, Kr_1] Xr_1;
    ##    int<lower=1> Kf_1;
    ##    matrix[N, Kf_1] Xf_1;
    ## }
    ## transformed data {
    ## }
    ## parameters{ 
    ##    real Intercept;
    ##    real<lower=0> sigma;
    ##    vector[Kr_1] zbr_1;
    ##    real<lower=0>sigmabr_1;
    ##    vector[Kf_1] bf_1;
    ## }
    ## transformed parameters { 
    ##    real lprior = 0;
    ##    vector[Kr_1] br_1;
    ##    br_1 = sigmabr_1 * zbr_1;
    ## }
    ## model{ 
    ##    vector[N] mu = rep_vector(0.0, N);
    ##    mu += Intercept + Xr_1 * br_1+ Xf_1 * bf_1;
    ##    for (n in 1:N) {
    ##      target += normal_lpdf(Y[n]|mu[n],sigma);
    ##    }
    ##    target += normal_lpdf(Intercept |plocation, pscale);
    ##    target += std_normal_lpdf(zbr_1);
    ##    target += inv_gamma_lpdf(sigmabr_1|0.0005,0.0005);
    ## }

``` r
curve_est=fit_stan$func_effect[[1]]
mean.curve.est=apply(curve_est,2,mean)
upper.curve.est=apply(curve_est,2,function(x){quantile(x,probs = 0.975)})
lower.curve.est=apply(curve_est,2,function(x){quantile(x,probs = 0.025)})






upper.curve.wald=upper.curve.est
lower.curve.wald=lower.curve.est

for(i in 1:length(upper.curve.est)){
  upper.curve.wald[i]=mean.curve.est[i]+1.96*sd(curve_est[,i])
  lower.curve.wald[i]=mean.curve.est[i]-1.96*sd(curve_est[,i])
  #print(sd(curve_est[,i]))
}


plotdata=data.frame(value=c(mean.curve.est,
                            upper.curve.est,
                            lower.curve.est,
                            true.beta,
                            plotfot[[1]]$fit[plot_inx]),
                    xmat=c(1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2]),
                    type=c(rep("mean",dim(exampleData$MIMS)[2]),
                           rep("upper",dim(exampleData$MIMS)[2]),
                           rep("lower",dim(exampleData$MIMS)[2]),
                           rep("true",dim(exampleData$MIMS)[2]),
                           rep("mgcv",dim(exampleData$MIMS)[2])))

ggplot(plotdata,aes(y=value,x=xmat))+geom_line(aes(type=type,color=type))
```

    ## Warning in geom_line(aes(type = type, color = type)): Ignoring unknown
    ## aesthetics: type

![](README_files/figure-gfm/unnamed-chunk-1-2.png)<!-- -->

``` r
exampleData_survival <- readRDS("./data/exampleData_survival.rds")

L_num=50
true.beta.func=function(x){
  (-(-0.5+(x-0.5)^2)-0.416)*5
}

true.beta=true.beta.func((1:L_num)/L_num)#+rnorm(1,mean = 1,sd=1)
            
            

fit_freq<- gam(survtime ~ s(tmat, by=lmat*MIMS, bs="cr", k=10), data=exampleData_survival,weights=event, family=cox.ph())
plotfot=plot(fit_freq)
```

![](README_files/figure-gfm/unnamed-chunk-2-1.png)<!-- -->

``` r
plotfot.upper=plotfot[[1]]$fit+plotfot[[1]]$se
plotfot.lower=plotfot[[1]]$fit-plotfot[[1]]$se

res.CI=c(as.numeric((true.beta<plotfot.upper[(1:50)*2])&(true.beta>plotfot.lower[(1:50)*2])))

plot_inx=c(1,round((1:(L_num-2))*(100/(L_num-1)),0),100)


exampleData_survival$cens=1-exampleData_survival$event

fit_stan<- bfrs(survtime ~ s(tmat, by=lmat*MIMS, bs="cr", k=10), data=exampleData_survival,
                family="Cox",func_comp="observ",cens="cens",n.knots = 4)
```

    ## Warning: There were 649 divergent transitions after warmup. See
    ## https://mc-stan.org/misc/warnings.html#divergent-transitions-after-warmup
    ## to find out why this is a problem and how to eliminate them.

    ## Warning: Examine the pairs() plot to diagnose sampling problems

    ## Warning: Bulk Effective Samples Size (ESS) is too low, indicating posterior means and medians may be unreliable.
    ## Running the chains for more iterations may help. See
    ## https://mc-stan.org/misc/warnings.html#bulk-ess

    ## Warning: Tail Effective Samples Size (ESS) is too low, indicating posterior variances and tail quantiles may be unreliable.
    ## Running the chains for more iterations may help. See
    ## https://mc-stan.org/misc/warnings.html#tail-ess

``` r
cat(fit_stan$Stancode)
```

    ## functions {
    ##    real cox_log_lhaz(real y, real log_mu, real bhaz, real cbhaz) {
    ##       return log(bhaz) + log_mu;
    ##    }
    ##    real cox_log_lccdf(real y, real log_mu, real bhaz, real cbhaz) {
    ##       return - cbhaz * exp(log_mu);
    ##    }
    ##    real cox_log_lcdf(real y, real log_mu, real bhaz, real cbhaz) {
    ##       return log1m_exp(cox_log_lccdf(y | log_mu, bhaz, cbhaz));
    ##    }
    ##    real cox_log_lpdf(real y, real log_mu, real bhaz, real cbhaz) {
    ##       return cox_log_lhaz(y, log_mu, bhaz, cbhaz) +
    ##              cox_log_lccdf(y | log_mu, bhaz, cbhaz);
    ##    }
    ## }
    ## data{ 
    ##    int<lower=1> N;
    ##    real real_inter;
    ##    array[N] int<lower=-1,upper=2> cens;
    ##    int Ksurvfunc;
    ##    vector<lower=0>[Ksurvfunc] con_sbhaz;
    ##    matrix[N, Ksurvfunc] Mbasis;
    ##    matrix[N, Ksurvfunc] Ibasis;
    ##    real Y[N];
    ##    int<lower=1> K_s;
    ##    int<lower=1> Kr_1;
    ##    matrix[N, Kr_1] Xr_1;
    ##    int<lower=1> Kf_1;
    ##    matrix[N, Kf_1] Xf_1;
    ## }
    ## transformed data {
    ## }
    ## parameters{ 
    ##    real Intercept;
    ##    simplex[Ksurvfunc] eta;
    ##    vector[Kr_1] zbr_1;
    ##    real<lower=0>sigmabr_1;
    ##    vector[Kf_1] bf_1;
    ## }
    ## transformed parameters { 
    ##    real lprior = 0;
    ##    vector[Kr_1] br_1;
    ##    br_1 = sigmabr_1 * zbr_1;
    ## }
    ## model{ 
    ##    vector[N] mu = rep_vector(0.0, N);
    ##    mu += Intercept + Xr_1 * br_1+ Xf_1 * bf_1;
    ##    vector[N] bhaz = Mbasis * eta;
    ##    vector[N] cbhaz = Ibasis * eta;
    ##    for (n in 1:N) {
    ##     if (cens[n] == 0) {
    ##       target += cox_log_lpdf(Y[n] | mu[n], bhaz[n], cbhaz[n]);
    ##     } else if (cens[n] == 1) {;   
    ##       target += cox_log_lccdf(Y[n] | mu[n], bhaz[n], cbhaz[n]);
    ##     } else if (cens[n] == -1) {   
    ##       target += cox_log_lcdf(Y[n] | mu[n], bhaz[n], cbhaz[n]);
    ##     }
    ##    }
    ##    target += normal_lpdf(Intercept | real_inter, 10);
    ##    target += dirichlet_lpdf(eta | con_sbhaz);
    ##    target += std_normal_lpdf(zbr_1);
    ##    target += inv_gamma_lpdf(sigmabr_1|0.0005,0.0005);
    ## }

``` r
curve_est=fit_stan$func_effect[[1]]
mean.curve.est=apply(curve_est,2,mean)
upper.curve.est=apply(curve_est,2,function(x){quantile(x,probs = 0.975)})
lower.curve.est=apply(curve_est,2,function(x){quantile(x,probs = 0.025)})






upper.curve.wald=upper.curve.est
lower.curve.wald=lower.curve.est

for(i in 1:length(upper.curve.est)){
  upper.curve.wald[i]=mean.curve.est[i]+1.96*sd(curve_est[,i])
  lower.curve.wald[i]=mean.curve.est[i]-1.96*sd(curve_est[,i])
  #print(sd(curve_est[,i]))
}


plotdata=data.frame(value=c(mean.curve.est,
                            upper.curve.est,
                            lower.curve.est,
                            true.beta,
                            plotfot[[1]]$fit[plot_inx]),
                    xmat=c(1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2],
                           1: dim(exampleData$MIMS)[2]),
                    type=c(rep("mean",dim(exampleData$MIMS)[2]),
                           rep("upper",dim(exampleData$MIMS)[2]),
                           rep("lower",dim(exampleData$MIMS)[2]),
                           rep("true",dim(exampleData$MIMS)[2]),
                           rep("mgcv",dim(exampleData$MIMS)[2])))

ggplot(plotdata,aes(y=value,x=xmat))+geom_line(aes(type=type,color=type))
```

    ## Warning in geom_line(aes(type = type, color = type)): Ignoring unknown
    ## aesthetics: type

![](README_files/figure-gfm/unnamed-chunk-2-2.png)<!-- -->
