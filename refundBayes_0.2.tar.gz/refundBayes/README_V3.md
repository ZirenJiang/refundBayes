---
editor_options: 
  markdown: 
    wrap: 72
---

# refundBayes 0.2.0 Vignette

## 2025-02-03

This vignette introduces the use of the `refundBayes` package with the
NHANES dataset. The `refundBayes` package provides users with a
convenient way to perform Bayesian functional data analysis using Stan,
a state-of-the-art Bayesian analysis language. The syntax of
`refundBayes` is designed to resemble that of `mgcv::gam`, but it
employs Bayesian posterior inference and includes additional arguments
specific to the Stan implementation.

### Key Features Demonstrated in this Vignette:

-   Fitting a Bayesian functional regression model with scalar (binary
    and Gaussian) outcomes using Stan.
-   Plotting pointwise and correlation and multiplicity-adjusted (CMA)
    credible intervals for estimated functional coefficients.
-   Performing Bayesian model diagnostics using trace plots.

We compare the Bayesian model output with the frequentist package `mgcv`
in terms of functional coefficient estimation.

------------------------------------------------------------------------

## Preparation

### Installing the `refundBayes` Package

The `refundBayes` package can be installed from the source file
available in this repository:

``` r
install.packages("refundBayes_0.2.tar.gz", type = "source", repos = NULL)
```

### Preparing the NHANES Dataset

NHANES (National Health and Nutrition Examination Survey) is a
nationwide study conducted by the CDC to assess the health and
nutritional status of U.S. residents. It is conducted in two-year waves
with approximately 10,000 participants per wave.

For this example, we analyze the association between scalar and
functional predictors and mortality in NHANES. The functional predictor
is the minute-level average daily physical activity measured using
accelerometers. Data was summarized in "Monitor Independent Movement
Summary" (MIMS) units and log-transformed to achieve a more symmetric
distribution. After processing, each participant has a 1,440-dimensional
vector of average log-MIMS values.

Mortality data was obtained by linking NHANES data to death certificate
records from the National Death Index, maintained by the National Center
for Health Statistics (NCHS), through 2019. The preprocessed dataset can
be downloaded from:

[Download NHANES
Dataset](http://www.ciprianstats.org/sites/default/files/nhanes/nhanes_fda_with_r.rds)

The study outcome is a binary indicator of five-year mortality, with
predictors including: - Minute-level physical activity (average
log-MIMS) - Age, gender, race, body mass index (BMI), poverty-to-income
ratio (PIR), coronary heart disease (CHD), and education level

We fit the following scalar-on-function regression (SoFR) model:

$$
logit(p_i) = \eta_0 + \int_{0}^1 W_i(t)\beta(t)dt + \mathbf{Z}_i^T\mathbf{\gamma}
$$

where:

-   $p_i$ is the probability of five-year mortality for participant
    $i$ - $\eta_0$ is the intercept,

-   $W_i(t)$ represents the functional predictor (physical activity),

-   $\beta(t)$ is the functional coefficient of interest,

-   $\mathbf{Z}_i$ is the vector of scalar predictors with corresponding
    coefficients $\gamma$.

After loading the data, we subset participants with fully observed
covariates:

``` r
set.seed(12345)
nhanes_fda_with_r <- readRDS("nhanes_fda_with_r.rds")

# Retain only participants with fully observed covariates
covariates <- c("age", "gender", "race", "BMI", "PIR", "CHD", "education")
nhanes_lite_use <- nhanes_fda_with_r
for (cova in covariates) {
  nhanes_lite_use <- nhanes_lite_use[!is.na(nhanes_lite_use[[cova]]), ]
}
nhanes_lite_use <- nhanes_lite_use[!is.na(nhanes_lite_use$event), ]
nhanes_lite_use <- nhanes_lite_use[nhanes_lite_use$CHD != "Refused", ]

# Create auxiliary matrices for functional regression
nhanes_lite_use$lmat <- matrix(1/1440, ncol = 1440, nrow = nrow(nhanes_lite_use))
nhanes_lite_use$tmat <- matrix(1:1440, ncol = 1440, nrow = nrow(nhanes_lite_use), byrow = TRUE)

# Define the outcome variable for five-year mortality
nhanes_lite_use$five_year_mort <- (nhanes_lite_use$time < 60) & (nhanes_lite_use$event == 1)
```

------------------------------------------------------------------------

## Frequentist Approach: `mgcv`

We first fit the SoFR model using the frequentist `mgcv` package:

``` r
library(mgcv)
fit_freq_b <- gam(five_year_mort ~ age + gender + race + BMI + PIR + CHD + education + s(tmat, by = lmat * MIMS, bs = "cc", k = 10),
                  data = nhanes_lite_use,
                  family = binomial())
```

### Explanation of the `gam` Syntax:

-   The response variable (`five_year_mort`) is followed by a tilde
    (`~`) and the linear predictor.
-   The `s()` function represents the integral term
    $\int_{0}^1 W_i(t)\beta(t)dt$.
-   Since the functional predictor is periodic (midnight is both 0 and
    24), we model $\beta(t)$ using a **cyclic cubic penalized regression
    spline**.
-   `s(tmat, by = lmat * MIMS, bs = "cc", k = 10)` constructs this
    spline with 10 basis functions.

### Frequentist Inference:

The pointwise confidence interval is obtained via:

``` r
plot.gam(fit_freq_b, unconditional = FALSE)
summary(fit_freq_b)
```

------------------------------------------------------------------------

## Bayesian Approach: `refundBayes`

We now fit the Bayesian functional regression model using `refundBayes`:

``` r
library(refundBayes)
fit_bfrs <- bfrs(five_year_mort ~ age + gender + race + BMI + PIR + CHD + education + s(tmat, by = lmat * MIMS, bs = "cc", k = 10),
                 data = nhanes_lite_use,
                 family = binomial(),
                 runStan = TRUE,
                 n.iter = 1500, 
                 n.warmup = 500, 
                 n.knots = 3)
```

### Bayesian Inference:

We can visualize the results:

``` r
library(ggplot2)
plot.bfrs(fit_bfrs, include = "both")
summary_scalar.bfrs(fit_bfrs)
```

### Bayesian Model Diagnostics:

Trace plots help check MCMC convergence:

``` r
traceplot(fit_bfrs$stanfit, pars = c("eta_0", "gamma"))
```

The trace plot confirms good convergence of posterior sampling.
